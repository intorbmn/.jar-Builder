package com.example.compassteleport;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.LodestoneTracker;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.entity.SignTextSlot;

import java.util.Optional;
import java.util.Set;

/**
 * Server-side only: click compass on a sign -> compass remembers your position + takes the sign's name.
 * Right-click the bound compass -> teleport back to that position.
 * The compass needle points at the saved position. Left-click is untouched (vanilla).
 */
public class CompassTeleport implements ModInitializer {
    public static final String MOD_ID = "compassteleport";
    private static final String TAG_ROOT = "compass_tp";
    private static final int COOLDOWN_TICKS = 40; // 2 giây, đổi tuỳ ý

    @Override
    public void onInitialize() {
        UseBlockCallback.EVENT.register(this::onUseBlock);
        UseItemCallback.EVENT.register(this::onUseItem);
    }

    // ---------- Click chuột phải vào biển bằng la bàn ----------
    private InteractionResult onUseBlock(Player player, Level level, InteractionHand hand,
                                         net.minecraft.world.phys.BlockHitResult hit) {
        if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(Items.COMPASS)) return InteractionResult.PASS;

        BlockPos pos = hit.getBlockPos();
        // Block khác sign: PASS để vanilla xử lý. Block tương tác được (rương, cửa, nút...) sẽ ưu tiên
        // tương tác; block không tương tác được thì rơi xuống onUseItem -> tp (giống cách ăn thức ăn).
        if (!(serverLevel.getBlockEntity(pos) instanceof SignBlockEntity sign)) return InteractionResult.PASS;

        // 26.3: getFrontText/getBackText đã bị xóa -> duyệt qua cả hai mặt bằng SignTextSlot
        String text = "";
        for (SignTextSlot slot : SignTextSlot.values()) {
            text = readSignText(sign.getText(slot));
            if (!text.isEmpty()) break;
        }
        if (text.isEmpty()) {
            sp.sendOverlayMessage(Component.literal("§cTấm biển này chưa có chữ!"));
            return InteractionResult.SUCCESS;
        }

        // Nếu cầm nhiều la bàn, chỉ tách 1 cái ra để gán
        ItemStack target;
        if (held.getCount() > 1) {
            target = held.copyWithCount(1);
            held.shrink(1);
        } else {
            target = held;
        }

        CompoundTag root = new CompoundTag();
        CompoundTag data = new CompoundTag();
        data.putString("dim", serverLevel.dimension().identifier().toString());
        data.putDouble("x", sp.getX());
        data.putDouble("y", sp.getY());
        data.putDouble("z", sp.getZ());
        data.putFloat("yaw", sp.getYRot());
        data.putFloat("pitch", sp.getXRot());
        root.put(TAG_ROOT, data);

        target.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
        setNeedle(target, serverLevel.dimension(), sp.getX(), sp.getY(), sp.getZ());
        target.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true); // hiệu ứng enchant, không có dòng enchant
        target.set(DataComponents.CUSTOM_NAME,
                Component.literal(text).withStyle(s -> s.withItalic(false)));

        if (target != held && !sp.getInventory().add(target)) {
            // inventory đầy -> thả la bàn xuống chân người chơi
            serverLevel.addFreshEntity(new ItemEntity(serverLevel, sp.getX(), sp.getY(), sp.getZ(), target));
        }

        sp.sendOverlayMessage(Component.literal("§aĐã lưu vị trí: §f" + text));
        return InteractionResult.SUCCESS;
    }

    // ---------- Click chuột phải (không trỏ vào block) bằng la bàn đã lưu ----------
    private InteractionResult onUseItem(Player player, Level level, InteractionHand hand) {
        if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        ItemStack stack = player.getItemInHand(hand);
        if (!stack.is(Items.COMPASS)) return InteractionResult.PASS;

        CustomData cd = stack.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return InteractionResult.PASS;
        CompoundTag root = cd.copyTag();
        if (!root.contains(TAG_ROOT)) return InteractionResult.PASS;
        CompoundTag data = root.getCompoundOrEmpty(TAG_ROOT);

        if (sp.getCooldowns().isOnCooldown(stack)) return InteractionResult.FAIL;

        Identifier dimId = Identifier.parse(data.getStringOr("dim", "minecraft:overworld"));
        ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, dimId);
        ServerLevel dest = sp.level().getServer().getLevel(key);
        if (dest == null) {
            sp.sendOverlayMessage(Component.literal("§cThế giới đích không tồn tại!"));
            return InteractionResult.FAIL;
        }

        double x = data.getDoubleOr("x", sp.getX());
        double y = data.getDoubleOr("y", sp.getY());
        double z = data.getDoubleOr("z", sp.getZ());
        float yaw = data.getFloatOr("yaw", sp.getYRot());
        float pitch = data.getFloatOr("pitch", sp.getXRot());

        // La bàn cũ (lưu trước khi có tính năng kim chỉ) -> bổ sung hướng chỉ
        if (stack.get(DataComponents.LODESTONE_TRACKER) == null) {
            setNeedle(stack, key, x, y, z);
        }

        sp.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
        sp.teleportTo(dest, x, y, z, Set.of(), yaw, pitch, true);
        sp.sendOverlayMessage(Component.literal("§bĐã dịch chuyển!"));
        return InteractionResult.SUCCESS;
    }

    /** Kim la bàn chỉ về tọa độ tp (tracked=false: không cần có lodestone thật ở đó). */
    private static void setNeedle(ItemStack stack, ResourceKey<Level> dim, double x, double y, double z) {
        GlobalPos target = GlobalPos.of(dim, BlockPos.containing(x, y, z));
        stack.set(DataComponents.LODESTONE_TRACKER, new LodestoneTracker(Optional.of(target), false));
    }

    private static String readSignText(SignText text) {
        StringBuilder sb = new StringBuilder();
        // 26.3: getMessages(boolean filtered) trả về List<Component>
        for (Component c : text.getMessages(false)) {
            String line = c.getString().trim();
            if (line.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(line);
        }
        return sb.toString();
    }
}
