package com.example.compassteleport;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;

import java.util.Set;

/**
 * Server-side only: click compass on a sign -> compass remembers your position + takes the sign's name.
 * Right-click the bound compass -> teleport back to that position.
 */
public class CompassTeleport implements ModInitializer {
    public static final String MOD_ID = "compassteleport";
    private static final String TAG_ROOT = "compass_tp";
    private static final int COOLDOWN_TICKS = 40; // 2 giây, đổi tuỳ ý

    @Override
    public void onInitialize() {
        UseBlockCallback.EVENT.register(this::onUseBlock);
        UseItemCallback.EVENT.register(this::onUseItem);
    }

    // ---------- Click chuột phải vào biển bằng la bàn ----------
    private InteractionResult onUseBlock(Player player, Level level, InteractionHand hand,
                                         net.minecraft.world.phys.BlockHitResult hit) {
        if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(Items.COMPASS)) return InteractionResult.PASS;

        BlockPos pos = hit.getBlockPos();
        if (!(serverLevel.getBlockEntity(pos) instanceof SignBlockEntity sign)) return InteractionResult.PASS;

        String text = readSignText(sign.getFrontText());
        if (text.isEmpty()) text = readSignText(sign.getBackText());
        if (text.isEmpty()) {
            sp.displayClientMessage(Component.literal("§cTấm biển này chưa có chữ!"), true);
            return InteractionResult.SUCCESS;
        }

        // Nếu cầm nhiều la bàn, chỉ tách 1 cái ra để gán
        ItemStack target;
        if (held.getCount() > 1) {
            target = held.copyWithCount(1);
            held.shrink(1);
        } else {
            target = held;
        }

        CompoundTag root = new CompoundTag();
        CompoundTag data = new CompoundTag();
        data.putString("dim", serverLevel.dimension().identifier().toString());
        data.putDouble("x", sp.getX());
        data.putDouble("y", sp.getY());
        data.putDouble("z", sp.getZ());
        data.putFloat("yaw", sp.getYRot());
        data.putFloat("pitch", sp.getXRot());
        root.put(TAG_ROOT, data);

        target.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
        target.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true); // hiệu ứng enchant, không có dòng enchant
        target.set(DataComponents.CUSTOM_NAME,
                Component.literal(text).withStyle(s -> s.withItalic(false)));

        if (target != held && !sp.getInventory().add(target)) {
            sp.drop(target, false);
        }

        sp.displayClientMessage(Component.literal("§aĐã lưu vị trí: §f" + text), true);
        return InteractionResult.SUCCESS;
    }

    // ---------- Click chuột phải (không trỏ vào block) bằng la bàn đã lưu ----------
    private InteractionResult onUseItem(Player player, Level level, InteractionHand hand) {
        if (!(level instanceof ServerLevel) || !(player instanceof ServerPlayer sp)) {
            return InteractionResult.PASS;
        }
        ItemStack stack = player.getItemInHand(hand);
        if (!stack.is(Items.COMPASS)) return InteractionResult.PASS;

        CustomData cd = stack.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return InteractionResult.PASS;
        CompoundTag root = cd.copyTag();
        if (!root.contains(TAG_ROOT)) return InteractionResult.PASS;
        CompoundTag data = root.getCompoundOrEmpty(TAG_ROOT);

        if (sp.getCooldowns().isOnCooldown(stack)) return InteractionResult.FAIL;

        Identifier dimId = Identifier.parse(data.getStringOr("dim", "minecraft:overworld"));
        ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, dimId);
        ServerLevel dest = sp.level().getServer().getLevel(key);
        if (dest == null) {
            sp.displayClientMessage(Component.literal("§cThế giới đích không tồn tại!"), true);
            return InteractionResult.FAIL;
        }

        double x = data.getDoubleOr("x", sp.getX());
        double y = data.getDoubleOr("y", sp.getY());
        double z = data.getDoubleOr("z", sp.getZ());
        float yaw = data.getFloatOr("yaw", sp.getYRot());
        float pitch = data.getFloatOr("pitch", sp.getXRot());

        sp.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
        sp.teleportTo(dest, x, y, z, Set.of(), yaw, pitch, true);
        sp.displayClientMessage(Component.literal("§bĐã dịch chuyển!"), true);
        return InteractionResult.SUCCESS;
    }

    private static String readSignText(SignText text) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            String line = text.getMessage(i, false).getString().trim();
            if (line.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(line);
        }
        return sb.toString();
    }
}
