Compass Teleport - Fabric mod cho Minecraft 26.3 (chạy riêng ở server)
=====================================================================
1. Cầm la bàn, đứng ở vị trí muốn lưu, chuột phải vào tấm biển (sign) đã ghi chữ.
   -> La bàn có hiệu ứng enchant (không có dòng enchant), tên đổi theo chữ trên biển,
      và lưu tọa độ/hướng nhìn/dimension nơi bạn đang đứng.
2. Cầm la bàn đã lưu rồi chuột phải -> dịch chuyển về đúng vị trí đã lưu.

Chỉ cần cài trên server (client vanilla vẫn vào được). Server cần Fabric API.

BUILD BẰNG GITHUB ACTIONS:
  - Đẩy toàn bộ nội dung thư mục này lên gốc repo (có thư mục .github/workflows).
  - Vào tab Actions -> "Build Compass Teleport" -> Run workflow (hoặc push là tự chạy).
  - Tải artifact "compass-teleport-jar" -> bên trong là file .jar.

BUILD TẠI MÁY (cần JDK 25 + Gradle 9.7 trở lên):
  gradle build   ->   build/libs/compass-teleport-1.0.0.jar

Cài đặt: bỏ jar vào thư mục mods của server, cùng Fabric API 0.155.0+26.3
và Fabric Loader >= 0.19.3.

Chỉnh thời gian chờ giữa 2 lần tp: COOLDOWN_TICKS trong
src/main/java/com/example/compassteleport/CompassTeleport.java (20 tick = 1 giây).
