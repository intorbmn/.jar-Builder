SkyGen - Fabric mod cho Minecraft 26.3
=====================================
Lava chảy gặp nước (hoặc ngược lại) -> thay vì luôn ra cobblestone, block sinh ra
được random giống ore generator trên server Skyblock:
cobblestone, than, đồng, sắt, vàng, redstone, lapis, kim cương, emerald.
Obsidian (lava nguồn + nước) vẫn như vanilla.

BUILD (cần JDK 25 + Gradle 9.7 trở lên, có mạng):
  1. Giải nén thư mục này
  2. Chạy:  gradle build
  3. File mod nằm ở  build/libs/skygen-1.0.0.jar
  4. Bỏ vào thư mục mods, cần Fabric Loader >= 0.19.3

Chỉnh tỉ lệ: src/main/java/com/skygen/OreTable.java (đổi số weight rồi build lại).

Nếu build lỗi vì tên method "fizz" hoặc tên plugin Loom, xem mục Lưu ý trong câu trả lời.
