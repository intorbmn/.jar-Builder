package com.skygen;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * Bảng xác suất của generator. Chỉnh số "weight" để đổi tỉ lệ.
 * Tỉ lệ = weight / tổng weight.
 */
public final class OreTable {
    private record Entry(Block block, int weight) {}

    private static final Entry[] ENTRIES = {
        new Entry(Blocks.COBBLESTONE,   600),
        new Entry(Blocks.COAL_ORE,      120),
        new Entry(Blocks.COPPER_ORE,     80),
        new Entry(Blocks.IRON_ORE,       90),
        new Entry(Blocks.GOLD_ORE,       40),
        new Entry(Blocks.REDSTONE_ORE,   40),
        new Entry(Blocks.LAPIS_ORE,      30),
        new Entry(Blocks.DIAMOND_ORE,    10),
        new Entry(Blocks.EMERALD_ORE,     5),
    };

    private static final int TOTAL;
    static {
        int t = 0;
        for (Entry e : ENTRIES) t += e.weight();
        TOTAL = t;
    }

    private OreTable() {}

    public static Block pick(RandomSource random) {
        int roll = random.nextInt(TOTAL);
        for (Entry e : ENTRIES) {
            roll -= e.weight();
            if (roll < 0) return e.block();
        }
        return Blocks.COBBLESTONE;
    }
}
