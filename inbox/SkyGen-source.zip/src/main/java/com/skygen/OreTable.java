package com.skygen;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * Bảng xác suất của generator. Chỉnh số "weight" để đổi tỉ lệ.
 * Tỉ lệ = weight / tổng weight.
 */
public final class OreTable {
    private record Entry(Block block, int weight) {}

    private static final Entry[] ENTRIES = {
	new Entry(Blocks.STONE,                  800),
	new Entry(Blocks.DEEPSLATE,               400),
	new Entry(Blocks.COBBLESTONE,             350),

	new Entry(Blocks.COAL_ORE,                180),
	new Entry(Blocks.DEEPSLATE_COAL_ORE,       80),

	new Entry(Blocks.COPPER_ORE,              150),
	new Entry(Blocks.DEEPSLATE_COPPER_ORE,     70),

	new Entry(Blocks.IRON_ORE,                130),
	new Entry(Blocks.DEEPSLATE_IRON_ORE,       80),

	new Entry(Blocks.GOLD_ORE,                 50),
	new Entry(Blocks.DEEPSLATE_GOLD_ORE,       30),

	new Entry(Blocks.REDSTONE_ORE,             55),
	new Entry(Blocks.DEEPSLATE_REDSTONE_ORE,   35),

	new Entry(Blocks.LAPIS_ORE,                45),
	new Entry(Blocks.DEEPSLATE_LAPIS_ORE,      25),

	new Entry(Blocks.DIAMOND_ORE,              15),
	new Entry(Blocks.DEEPSLATE_DIAMOND_ORE,     8),

	new Entry(Blocks.EMERALD_ORE,               5),
	new Entry(Blocks.DEEPSLATE_EMERALD_ORE,     2),

	new Entry(Blocks.ANCIENT_DEBRIS,            1),
    };

    private static final int TOTAL;
    static {
        int t = 0;
        for (Entry e : ENTRIES) t += e.weight();
        TOTAL = t;
    }

    private OreTable() {}

    public static Block pick(RandomSource random) {
        int roll = random.nextInt(TOTAL);
        for (Entry e : ENTRIES) {
            roll -= e.weight();
            if (roll < 0) return e.block();
        }
        return Blocks.COBBLESTONE;
    }
}
