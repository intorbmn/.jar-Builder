package com.skygen.mixin;

import com.skygen.OreTable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Khi lava gặp nước, vanilla đặt cobblestone rồi gọi fizz() (âm thanh + khói).
 * Ta chèn vào đầu fizz(): nếu block vừa tạo là cobblestone thì đổi thành
 * block ngẫu nhiên theo OreTable. Obsidian (lava source) giữ nguyên.
 */
@Mixin(LiquidBlock.class)
public abstract class LiquidBlockMixin {

    @Inject(method = "fizz", at = @At("HEAD"))
    private void skygen$oreGenerator(LevelAccessor level, BlockPos pos, CallbackInfo ci) {
        if (level.getBlockState(pos).is(Blocks.COBBLESTONE)) {
            level.setBlock(pos, OreTable.pick(level.getRandom()).defaultBlockState(), 3);
        }
    }
}
